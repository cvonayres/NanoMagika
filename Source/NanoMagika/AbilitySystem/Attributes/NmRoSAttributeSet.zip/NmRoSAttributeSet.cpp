// Copyright Electronic CAD Monkey [ECM]

#include "NmRoSAttributeSet.h"
#include "AbilitySystemBlueprintLibrary.h"
#include "GameplayEffectExtension.h"
#include "NanoMagika/ECMGameplayTags.h"
#include "Net/UnrealNetwork.h"

struct AttributeFunctionMappings
{
	FGameplayAttribute Attribute;
	float (UNmRoSAttributeSet::*Getter)() const = nullptr;
	void (UNmRoSAttributeSet::*Setter)(float) = nullptr;
	float (UNmRoSAttributeSet::*MaxFunc)() const;
};

#pragma region Mapping
UNmRoSAttributeSet::UNmRoSAttributeSet()
{
	const FECMGameplayTags& GameplayTags = FECMGameplayTags::Get();

	// Primary Attributes to be mapped
	TagsToAttributes.Add(GameplayTags.Attribute_Primary_Physique, GetPhysiqueAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Primary_Adaptivity, GetAdaptivityAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Primary_NeuralAgility, GetNeuralAgilityAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Primary_EmpathicResonance, GetEmpathicResonanceAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Primary_EssenceControl, GetEssenceControlAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Primary_Nanomancy, GetNanomancyAttribute);

	// Secondary Attributes to be mapped
	TagsToAttributes.Add(GameplayTags.Attribute_Secondary_VMCapacity, GetVMCapacityAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Secondary_VMRecovery, GetVMRecoveryAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Secondary_EECapacity, GetEECapacityAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Secondary_EERecovery, GetEERecoveryAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Secondary_ARCapacity, GetARCapacityAttribute);
    TagsToAttributes.Add(GameplayTags.Attribute_Secondary_ARRecovery, GetARRecoveryAttribute);

	TagsToAttributes.Add(GameplayTags.Attribute_Secondary_ResonanceSyncQuality, GetResonanceSyncQualityAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Secondary_ResonanceAmplification, GetResonanceAmplificationAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Secondary_EmpathicInfluence, GetEmpathicInfluenceAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Secondary_TechnologicalInterface, GetTechnologicalInterfaceAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Secondary_SignalStealth, GetSignalStealthAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Secondary_ReactionSpeed, GetReactionSpeedAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Secondary_DimensionalPocketCapacity, GetDimensionalPocketCapacityAttribute);

	// Tertiary Attributes to be mapped

}
#pragma endregion Mapping

#pragma region Clamping
// Define Primary Attributes for Clamping
TArray<AttributeFunctionMappings> UNmRoSAttributeSet::GetPrimaryValvesMappings()
{
	return {
		        { GetPhysiqueAttribute(), &UNmRoSAttributeSet::GetPhysique, &UNmRoSAttributeSet::SetPhysique, &UNmRoSAttributeSet::GetMaxPrimary },
				{ GetAdaptivityAttribute(), &UNmRoSAttributeSet::GetAdaptivity, &UNmRoSAttributeSet::SetAdaptivity, &UNmRoSAttributeSet::GetMaxPrimary },
				{ GetNeuralAgilityAttribute(), &UNmRoSAttributeSet::GetNeuralAgility, &UNmRoSAttributeSet::SetNeuralAgility, &UNmRoSAttributeSet::GetMaxPrimary },
				{ GetEmpathicResonanceAttribute(), &UNmRoSAttributeSet::GetEmpathicResonance, &UNmRoSAttributeSet::SetEmpathicResonance, &UNmRoSAttributeSet::GetMaxPrimary },
				{ GetEssenceControlAttribute(), &UNmRoSAttributeSet::GetEssenceControl, &UNmRoSAttributeSet::SetEssenceControl, &UNmRoSAttributeSet::GetMaxPrimary },
				{ GetNanomancyAttribute(), &UNmRoSAttributeSet::GetNanomancy, &UNmRoSAttributeSet::SetNanomancy, &UNmRoSAttributeSet::GetMaxPrimary },
			};
}

// Clamp Valves
void UNmRoSAttributeSet::PreAttributeChange(const FGameplayAttribute& Attribute, float& NewValue)
{
	Super::PreAttributeChange(Attribute, NewValue);

	ClampAttributeInSet(Attribute,GetPrimaryValvesMappings());
}

// Harvest Data & Clamp again
void UNmRoSAttributeSet::PostGameplayEffectExecute(const FGameplayEffectModCallbackData& Data)
{
	Super::PostGameplayEffectExecute(Data);
	
	ClampAttributeInSet(AttributeFromData(Data),GetPrimaryValvesMappings());
}
#pragma endregion Clamping

#pragma region Replicate
// Replicate attributes
void UNmRoSAttributeSet::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	
	// Primary Attributes to be replicated
	DOREPLIFETIME_CONDITION_NOTIFY(UNmRoSAttributeSet, Physique, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UNmRoSAttributeSet, Adaptivity, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UNmRoSAttributeSet, NeuralAgility, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UNmRoSAttributeSet, EmpathicResonance, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UNmRoSAttributeSet, EssenceControl, COND_None, REPNOTIFY_Always);

	// Secondary Attributes to be replicated
	DOREPLIFETIME_CONDITION_NOTIFY(UNmRoSAttributeSet, VMRecovery, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UNmRoSAttributeSet, EERecovery, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UNmRoSAttributeSet, ARRecovery, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UNmRoSAttributeSet, ResonanceSyncQuality, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UNmRoSAttributeSet, ResonanceAmplification, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UNmRoSAttributeSet, EmpathicInfluence, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UNmRoSAttributeSet, TechnologicalInterface, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UNmRoSAttributeSet, SignalStealth, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UNmRoSAttributeSet, ReactionSpeed, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UNmRoSAttributeSet, DimensionalPocketCapacity, COND_None, REPNOTIFY_Always);
}

#pragma region RefNofifies
// Macro for creating  repetitive Repfunctions
#define DEFINE_ATTRIBUTE_REPNOTIFY(ClassName, AttributeName) \
void ClassName::OnRep_##AttributeName(const FGameplayAttributeData& Old##AttributeName) const \
{ \
GAMEPLAYATTRIBUTE_REPNOTIFY(ClassName, AttributeName, Old##AttributeName); \
}

// Primary - Gameplay Attributes
DEFINE_ATTRIBUTE_REPNOTIFY(UNmRoSAttributeSet, Physique)
DEFINE_ATTRIBUTE_REPNOTIFY(UNmRoSAttributeSet, Adaptivity)
DEFINE_ATTRIBUTE_REPNOTIFY(UNmRoSAttributeSet, NeuralAgility)
DEFINE_ATTRIBUTE_REPNOTIFY(UNmRoSAttributeSet, EmpathicResonance)
DEFINE_ATTRIBUTE_REPNOTIFY(UNmRoSAttributeSet, EssenceControl)
DEFINE_ATTRIBUTE_REPNOTIFY(UNmRoSAttributeSet, Nanomancy)

// Secondary - Gameplay Attributes
DEFINE_ATTRIBUTE_REPNOTIFY(UNmRoSAttributeSet, VMRecovery)
DEFINE_ATTRIBUTE_REPNOTIFY(UNmRoSAttributeSet, EERecovery)
DEFINE_ATTRIBUTE_REPNOTIFY(UNmRoSAttributeSet, ARRecovery)
DEFINE_ATTRIBUTE_REPNOTIFY(UNmRoSAttributeSet, ResonanceSyncQuality)
DEFINE_ATTRIBUTE_REPNOTIFY(UNmRoSAttributeSet, ResonanceAmplification)
DEFINE_ATTRIBUTE_REPNOTIFY(UNmRoSAttributeSet, EmpathicInfluence)
DEFINE_ATTRIBUTE_REPNOTIFY(UNmRoSAttributeSet, TechnologicalInterface)
DEFINE_ATTRIBUTE_REPNOTIFY(UNmRoSAttributeSet, SignalStealth)
DEFINE_ATTRIBUTE_REPNOTIFY(UNmRoSAttributeSet, ReactionSpeed)
DEFINE_ATTRIBUTE_REPNOTIFY(UNmRoSAttributeSet, DimensionalPocketCapacity)

// Tertiary - Gameplay Attributes
#pragma endregion Replicate

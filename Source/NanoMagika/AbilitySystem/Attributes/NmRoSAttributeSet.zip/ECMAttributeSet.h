// Copyright Electronic CAD Monkey [ECM]

#pragma once

#include "CoreMinimal.h"
#include "AttributeSet.h"
#include "AbilitySystemComponent.h"
#include "ECMAttributeSet.generated.h"

#pragma region Macros
// Macro for creating attribute getters, setters,etc
#define ATTRIBUTE_ACCESSORS(ClassName, PropertyName) \
GAMEPLAYATTRIBUTE_PROPERTY_GETTER(ClassName, PropertyName) \
GAMEPLAYATTRIBUTE_VALUE_GETTER(PropertyName) \
GAMEPLAYATTRIBUTE_VALUE_SETTER(PropertyName) \
GAMEPLAYATTRIBUTE_VALUE_INITTER(PropertyName)
#pragma endregion Macros

struct AttributeFunctionMappings;

USTRUCT()
struct FEffectProperties
{
	GENERATED_BODY()

	FEffectProperties(){}

	//  Effect Context Handle
	UPROPERTY()
	FGameplayEffectContextHandle EffectContextHandle;
	
	// Source Info
	UPROPERTY()
	UAbilitySystemComponent* SourceASC = nullptr;
	UPROPERTY()
	AActor* SourceAvatarActor = nullptr;
	UPROPERTY()
	AController* SourceController = nullptr;
	UPROPERTY()
	ACharacter* SourceCharacter = nullptr;

	// Target Avatar Info
	UPROPERTY()
	UAbilitySystemComponent* TargetASC = nullptr;
	UPROPERTY()
	AActor* TargetAvatarActor = nullptr;
	UPROPERTY()
	AController* TargetController = nullptr;
	UPROPERTY()
	ACharacter* TargetCharacter = nullptr;
};

//  TStaticFuncPtr generic to specified function
template<class T>
using TStaticFuncPtr = typename TBaseStaticDelegateInstance<T, FDefaultDelegateUserPolicy>::FFuncPtr;

UCLASS()
class NANOMAGIKA_API UECMAttributeSet : public UAttributeSet
{
	GENERATED_BODY()

public:
	UECMAttributeSet();
	
	// Replicate variables
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	// Used to Clamp Attributes before change
	virtual void PreAttributeChange(const FGameplayAttribute& Attribute, float& NewValue) override;

	// Used to Clamp Attributes after change and harvest data of change
	virtual void PostGameplayEffectExecute(const FGameplayEffectModCallbackData& Data) override;

	// Returns attribute from Gameplay Tag
	TMap<FGameplayTag, TStaticFuncPtr<FGameplayAttribute()>> TagsToAttributes;
	
// Vital - Gameplay Attributes
#pragma region VitalAttributes
		UPROPERTY(BlueprintReadOnly, Category = "Attributes|Vital", ReplicatedUsing = OnRep_VitalityMatrix)
		FGameplayAttributeData VitalityMatrix;
		ATTRIBUTE_ACCESSORS(UECMAttributeSet, VitalityMatrix);

		UPROPERTY(BlueprintReadOnly, Category = "Attributes|Vital", ReplicatedUsing = OnRep_EnergeticEndurance)
		FGameplayAttributeData EnergeticEndurance;
		ATTRIBUTE_ACCESSORS(UECMAttributeSet, EnergeticEndurance);

		UPROPERTY(BlueprintReadOnly, Category = "Attributes|Vital", ReplicatedUsing = OnRep_ArcaneReservoir)
		FGameplayAttributeData ArcaneReservoir;
		ATTRIBUTE_ACCESSORS(UECMAttributeSet, ArcaneReservoir);
	
		UPROPERTY(BlueprintReadOnly, Category = "Attributes|Vital", ReplicatedUsing = OnRep_DefensiveSynchrony)
		FGameplayAttributeData DefensiveSynchrony;
		ATTRIBUTE_ACCESSORS(UECMAttributeSet, DefensiveSynchrony);
	
		UPROPERTY(BlueprintReadOnly, Category = "Attributes|Vital", ReplicatedUsing = OnRep_BarrierMatrix)
		FGameplayAttributeData BarrierMatrix;
		ATTRIBUTE_ACCESSORS(UECMAttributeSet, BarrierMatrix);

	#pragma region Vital_OnReps
		UFUNCTION()
		void OnRep_VitalityMatrix(const FGameplayAttributeData& OldVM) const;
		UFUNCTION()
		void OnRep_EnergeticEndurance(const FGameplayAttributeData& OldEE) const;
		UFUNCTION()
		void OnRep_ArcaneReservoir(const FGameplayAttributeData& OldAR) const;
		UFUNCTION()
		void OnRep_DefensiveSynchrony(const FGameplayAttributeData& OldDS) const;
		UFUNCTION()
		void OnRep_BarrierMatrix(const FGameplayAttributeData& OldBM) const;
	#pragma endregion Vital_OnReps
#pragma endregion VitalAttributes
	
// Secondary - Gameplay Attributes
#pragma region SecondaryAttributes
	#pragma region Stats
	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Secondary", ReplicatedUsing = OnRep_VMCapacity)
	FGameplayAttributeData VMCapacity;
	ATTRIBUTE_ACCESSORS(UECMAttributeSet, VMCapacity);

	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Secondary", ReplicatedUsing = OnRep_EECapacity)
	FGameplayAttributeData EECapacity;
	ATTRIBUTE_ACCESSORS(UECMAttributeSet, EECapacity);

	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Secondary", ReplicatedUsing = OnRep_ARCapacity)
	FGameplayAttributeData ARCapacity;
	ATTRIBUTE_ACCESSORS(UECMAttributeSet, ARCapacity);

	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Secondary", ReplicatedUsing = OnRep_KineticAbsorption)
	FGameplayAttributeData KineticAbsorption;
	ATTRIBUTE_ACCESSORS(UECMAttributeSet, KineticAbsorption);
	
	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Secondary", ReplicatedUsing = OnRep_NanoshieldThreshold)
	FGameplayAttributeData NanoshieldThreshold;
	ATTRIBUTE_ACCESSORS(UECMAttributeSet, NanoshieldThreshold);

#pragma region Secondary_OnRep
	UFUNCTION()
	void OnRep_VMCapacity(const FGameplayAttributeData& OldVM) const;
	UFUNCTION()
	void OnRep_EECapacity(const FGameplayAttributeData& OldEE) const;
	UFUNCTION()
	void OnRep_ARCapacity(const FGameplayAttributeData& OldAR) const;
	UFUNCTION()
	void OnRep_KineticAbsorption(const FGameplayAttributeData& OldKA) const;
	UFUNCTION()
	void OnRep_NanoshieldThreshold(const FGameplayAttributeData& OldNST) const;

	
#pragma endregion Stats
	
// Meta - Gameplay Attributes
#pragma region MetaAttributes
	UPROPERTY(BlueprintReadOnly, Category = "Meta Attributes")
	FGameplayAttributeData IncomingDamage;
	ATTRIBUTE_ACCESSORS(UECMAttributeSet, IncomingDamage);
#pragma endregion MetaAttributes

protected:
	static void SetEffectProperties(const FGameplayEffectModCallbackData& Data, FEffectProperties &Props);

	// Container for Attribute Mappings
	static TArray<AttributeFunctionMappings> GetVitalValvesMappings();

	static FGameplayAttribute AttributeFromData(const FGameplayEffectModCallbackData& Data);

	void ClampAttributeInSet (const FGameplayAttribute& Attribute, TArray<AttributeFunctionMappings> AttributeSet);

};

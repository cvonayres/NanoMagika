// Copyright Electronic CAD Monkey [ECM]

#pragma once

#include "CoreMinimal.h"
#include "ECMAttributeSet.h"
#include "NmRoSAttributeSet.generated.h"

#pragma region Macros
// Macro for creating attribute getters, setters,etc
#define ATTRIBUTE_ACCESSORS2(ClassName, PropertyName) \
GAMEPLAYATTRIBUTE_PROPERTY_GETTER(ClassName, PropertyName) \
GAMEPLAYATTRIBUTE_VALUE_GETTER(PropertyName) \
GAMEPLAYATTRIBUTE_VALUE_SETTER(PropertyName) \
GAMEPLAYATTRIBUTE_VALUE_INITTER(PropertyName)
#pragma endregion Macros

UCLASS()
class NANOMAGIKA_API UNmRoSAttributeSet : public UECMAttributeSet
{
	GENERATED_BODY()

	UNmRoSAttributeSet();
	
public:
	// Replicate variables
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	// Used to Clamp Attributes before change
	virtual void PreAttributeChange(const FGameplayAttribute& Attribute, float& NewValue) override;

	// Used to Clamp Attributes after change and harvest data of change
	virtual void PostGameplayEffectExecute(const FGameplayEffectModCallbackData& Data) override;

// Primary - Gameplay Attributes
#pragma region PrimaryAttributes
	#pragma region Stats
	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Primary")
	FGameplayAttributeData MaxPrimary;
	ATTRIBUTE_ACCESSORS2(UNmRoSAttributeSet, MaxPrimary);
	
	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Primary", ReplicatedUsing = OnRep_Physique)
	FGameplayAttributeData Physique;
	ATTRIBUTE_ACCESSORS2(UNmRoSAttributeSet, Physique);

	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Primary", ReplicatedUsing = OnRep_Adaptivity)
	FGameplayAttributeData Adaptivity;
	ATTRIBUTE_ACCESSORS2(UNmRoSAttributeSet, Adaptivity);

	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Primary", ReplicatedUsing = OnRep_NeuralAgility)
	FGameplayAttributeData NeuralAgility;
	ATTRIBUTE_ACCESSORS2(UNmRoSAttributeSet, NeuralAgility);

	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Primary", ReplicatedUsing = OnRep_EmpathicResonance)
	FGameplayAttributeData EmpathicResonance;
	ATTRIBUTE_ACCESSORS2(UNmRoSAttributeSet, EmpathicResonance);

	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Primary", ReplicatedUsing = OnRep_EssenceControl)
	FGameplayAttributeData EssenceControl;
	ATTRIBUTE_ACCESSORS2(UNmRoSAttributeSet, EssenceControl);

	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Primary", ReplicatedUsing = OnRep_Nanomancy)
	FGameplayAttributeData Nanomancy;
	ATTRIBUTE_ACCESSORS2(UNmRoSAttributeSet, Nanomancy);
#pragma endregion Stats
	
#pragma region Priamry_OnReps
	// Vital - OnReps
	UFUNCTION()
	void OnRep_Physique(const FGameplayAttributeData& OldPhy) const;
	UFUNCTION()
	void OnRep_Adaptivity(const FGameplayAttributeData& OldAD) const;
	UFUNCTION()
	void OnRep_NeuralAgility(const FGameplayAttributeData& OldNA) const;
	UFUNCTION()
	void OnRep_EmpathicResonance(const FGameplayAttributeData& OldER) const;
	UFUNCTION()
	void OnRep_EssenceControl(const FGameplayAttributeData& OldEC) const;
	UFUNCTION()
	void OnRep_Nanomancy(const FGameplayAttributeData& OldNM) const;
	#pragma endregion Priamry_OnReps
#pragma endregion PrimaryAttributes

// Secondary - Gameplay Attributes
#pragma region SecondaryAttributes
	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Secondary", ReplicatedUsing = OnRep_VMRecovery)
	FGameplayAttributeData VMRecovery;
	ATTRIBUTE_ACCESSORS2(UNmRoSAttributeSet, VMRecovery);
	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Secondary", ReplicatedUsing = OnRep_EERecovery)
	FGameplayAttributeData EERecovery;
	ATTRIBUTE_ACCESSORS2(UNmRoSAttributeSet, EERecovery);
	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Secondary", ReplicatedUsing = OnRep_ARRecovery)
	FGameplayAttributeData ARRecovery;
	ATTRIBUTE_ACCESSORS2(UNmRoSAttributeSet, ARRecovery);

	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Secondary", ReplicatedUsing = OnRep_ResonanceSyncQuality)
	FGameplayAttributeData ResonanceSyncQuality;
	ATTRIBUTE_ACCESSORS2(UNmRoSAttributeSet, ResonanceSyncQuality);
	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Secondary", ReplicatedUsing = OnRep_ResonanceAmplification)
	FGameplayAttributeData ResonanceAmplification;
	ATTRIBUTE_ACCESSORS2(UNmRoSAttributeSet, ResonanceAmplification);

	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Secondary", ReplicatedUsing = OnRep_EmpathicInfluence)
	FGameplayAttributeData EmpathicInfluence;
	ATTRIBUTE_ACCESSORS2(UNmRoSAttributeSet, EmpathicInfluence);
	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Secondary", ReplicatedUsing = OnRep_TechnologicalInterface)
	FGameplayAttributeData TechnologicalInterface;
	ATTRIBUTE_ACCESSORS2(UNmRoSAttributeSet, TechnologicalInterface);

	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Secondary", ReplicatedUsing = OnRep_SignalStealth)
	FGameplayAttributeData SignalStealth;
	ATTRIBUTE_ACCESSORS2(UNmRoSAttributeSet, SignalStealth);
	
	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Secondary", ReplicatedUsing = OnRep_ReactionSpeed)
	FGameplayAttributeData ReactionSpeed;
	ATTRIBUTE_ACCESSORS2(UNmRoSAttributeSet, ReactionSpeed);

	UPROPERTY(BlueprintReadOnly, Category = "Attributes|Secondary", ReplicatedUsing = OnRep_DimensionalPocketCapacity)
	FGameplayAttributeData DimensionalPocketCapacity;
	ATTRIBUTE_ACCESSORS2(UNmRoSAttributeSet, DimensionalPocketCapacity);
#pragma endregion Stats
	
	#pragma region Secondary_OnReps
	UFUNCTION()
	void OnRep_VMRecovery(const FGameplayAttributeData& OldVMR) const;
	UFUNCTION()
	void OnRep_EERecovery(const FGameplayAttributeData& OldEER) const;
	UFUNCTION()
	void OnRep_ARRecovery(const FGameplayAttributeData& OldARR) const;

	UFUNCTION()
	void OnRep_ResonanceSyncQuality(const FGameplayAttributeData& OldRSQ) const;
	UFUNCTION()
	void OnRep_ResonanceAmplification(const FGameplayAttributeData& OldRA) const;
	UFUNCTION()
	void OnRep_EmpathicInfluence(const FGameplayAttributeData& OldEI) const;
	UFUNCTION()
	void OnRep_TechnologicalInterface(const FGameplayAttributeData& OldTI) const;
	UFUNCTION()
	void OnRep_SignalStealth(const FGameplayAttributeData& OldSS) const;
	UFUNCTION()
	void OnRep_ReactionSpeed(const FGameplayAttributeData& OldRS) const;
	UFUNCTION()
	void OnRep_DimensionalPocketCapacity(const FGameplayAttributeData& OldDPC) const;
	#pragma endregion Secondary_OnReps
#pragma endregion SecondaryAttributes

// Tertiary - Gameplay Attributes
#pragma region TertiaryAttributes
#pragma endregion TertiaryAttributes

private:
	static TArray<AttributeFunctionMappings> GetPrimaryValvesMappings();

	// Maximum valve for Primary Attributes
	UPROPERTY(VisibleAnywhere,Category="Attributes")
	float MaxPrimaryAttribute = 20.f;


};

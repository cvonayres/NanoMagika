// Copyright Electronic CAD Monkey [ECM]

#include "ECMAttributeSet.h"
#include "AbilitySystemBlueprintLibrary.h"
#include "GameplayEffectExtension.h"
#include "GameFramework/Character.h"
#include "NanoMagika/ECMGameplayTags.h"
#include "Net/UnrealNetwork.h"

struct AttributeFunctionMappings
{
	FGameplayAttribute Attribute;
	float (UECMAttributeSet::*Getter)() const = nullptr;
	void (UECMAttributeSet::*Setter)(float) = nullptr;
	float (UECMAttributeSet::*MaxFunc)() const;
};

#pragma region Mapping
UECMAttributeSet::UECMAttributeSet()
{
	const FECMGameplayTags& GameplayTags = FECMGameplayTags::Get();
	
	// Vital Attributes to be mapped
	TagsToAttributes.Add(GameplayTags.Attribute_Vital_VitalityMatrix, GetVitalityMatrixAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Vital_EnergeticEndurance, GetEnergeticEnduranceAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Vital_ArcaneReservoir, GetArcaneReservoirAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Vital_DefensiveSynchrony, GetDefensiveSynchronyAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Vital_EnergeticEndurance, GetEnergeticEnduranceAttribute);
	
	// Primary Attributes to be mapped

	// Secondary Attributes to be mapped
	TagsToAttributes.Add(GameplayTags.Attribute_Secondary_VMCapacity, GetVMCapacityAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Secondary_EECapacity, GetEECapacityAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Secondary_ARCapacity, GetARCapacityAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Secondary_KineticAbsorption, GetKineticAbsorptionAttribute);
	TagsToAttributes.Add(GameplayTags.Attribute_Secondary_NanoshieldThreshold, GetNanoshieldThresholdAttribute);
}
#pragma endregion Mapping

#pragma region Clamping
// Define Vital Attributes for Clamping
TArray<AttributeFunctionMappings> UECMAttributeSet::GetVitalValvesMappings()
{
	return {
		        { GetVitalityMatrixAttribute(), &UECMAttributeSet::GetVitalityMatrix, &UECMAttributeSet::SetVitalityMatrix, &UECMAttributeSet::GetVMCapacity },
				{ GetEnergeticEnduranceAttribute(), &UECMAttributeSet::GetEnergeticEndurance, &UECMAttributeSet::SetEnergeticEndurance, &UECMAttributeSet::GetEECapacity },
				{ GetArcaneReservoirAttribute(), &UECMAttributeSet::GetArcaneReservoir, &UECMAttributeSet::SetArcaneReservoir, &UECMAttributeSet::GetARCapacity },
				{ GetDefensiveSynchronyAttribute(), &UECMAttributeSet::GetDefensiveSynchrony, &UECMAttributeSet::SetDefensiveSynchrony, &UECMAttributeSet::GetKineticAbsorption },
				{ GetBarrierMatrixAttribute(), &UECMAttributeSet::GetBarrierMatrix, &UECMAttributeSet::SetBarrierMatrix, &UECMAttributeSet::GetNanoshieldThreshold }
	};
}

// Clamp Valves
void UECMAttributeSet::PreAttributeChange(const FGameplayAttribute& Attribute, float& NewValue)
{
	Super::PreAttributeChange(Attribute, NewValue);

	ClampAttributeInSet(Attribute,GetVitalValvesMappings());
}

// Harvest Data & Clamp again
void UECMAttributeSet::PostGameplayEffectExecute(const FGameplayEffectModCallbackData& Data)
{
	Super::PostGameplayEffectExecute(Data);

	ClampAttributeInSet(AttributeFromData(Data),GetVitalValvesMappings());
	
	///. DAMAGE CAL
	
	if (Data.EvaluatedData.Attribute == GetIncomingDamageAttribute())
	{
		const float LocalIncomingDamage = GetIncomingDamage();
		SetIncomingDamage(0.f);
		if( LocalIncomingDamage > 0.f)
		{
			const float NewHealth  = GetVitalityMatrix() - LocalIncomingDamage;
			SetVitalityMatrix(FMath::Clamp(NewHealth, 0, GetVMCapacity()));

			const bool bFatal = NewHealth <- 0.f;
		}
	}
}

void UECMAttributeSet::SetEffectProperties(const FGameplayEffectModCallbackData& Data, FEffectProperties& Props)
{
	// Source = causer, Target = target of the effect (owner of this AS)

	//Get Context Handle
	Props.EffectContextHandle = Data.EffectSpec.GetContext();

	//Get Source Ability System Component
	Props.SourceASC = Props.EffectContextHandle.GetOriginalInstigatorAbilitySystemComponent();

	// Get Source Actor, Controller & Character
	if(IsValid(Props.SourceASC) && Props.SourceASC->AbilityActorInfo.IsValid() && Props.SourceASC->AbilityActorInfo->AvatarActor.IsValid())
	{
		Props.SourceAvatarActor =  Props.SourceASC->AbilityActorInfo->AvatarActor.Get();
		if(Props.SourceASC->AbilityActorInfo)
		{
			Props.SourceController = Props.SourceASC->AbilityActorInfo->PlayerController.Get();
			if(Props.SourceController == nullptr && Props.SourceAvatarActor != nullptr)
			{
				if (const APawn* Pawn = Cast<APawn>(Props.SourceAvatarActor))
				{
					Props.SourceController = Pawn->GetController();
				}
			}
			if(Props.SourceController)
			{
				Props.SourceCharacter = Cast<ACharacter>(Props.SourceController->GetPawn());
			}
		}
	}

	// Get Target Actor, Controller & Character
	if(Data.Target.AbilityActorInfo.IsValid() && Data.Target.AbilityActorInfo->AvatarActor.IsValid())
	{
		Props.TargetAvatarActor = Data.Target.AbilityActorInfo->AvatarActor.Get();
		Props.TargetController = Data.Target.AbilityActorInfo->PlayerController.Get();
		Props.TargetCharacter = Cast<ACharacter>(Props.TargetAvatarActor);
		UAbilitySystemComponent* TargetASC = UAbilitySystemBlueprintLibrary::GetAbilitySystemComponent(Props.TargetAvatarActor);
	}
}
#pragma endregion Clamping

#pragma region Replicate
// Replicate attributes
void UECMAttributeSet::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	// Vital Attributes to be replicated
	DOREPLIFETIME_CONDITION_NOTIFY(UECMAttributeSet, VitalityMatrix, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UECMAttributeSet, EnergeticEndurance, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UECMAttributeSet, ArcaneReservoir, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UECMAttributeSet, DefensiveSynchrony, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UECMAttributeSet, BarrierMatrix, COND_None, REPNOTIFY_Always);
	
	// Secondary Attributes to be replicated
	DOREPLIFETIME_CONDITION_NOTIFY(UECMAttributeSet, VMCapacity, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UECMAttributeSet, EECapacity, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UECMAttributeSet, ARCapacity, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UECMAttributeSet, KineticAbsorption, COND_None, REPNOTIFY_Always);
	DOREPLIFETIME_CONDITION_NOTIFY(UECMAttributeSet, NanoshieldThreshold, COND_None, REPNOTIFY_Always);
}

// Macro for creating  repetitive Repfunctions
#define DEFINE_ATTRIBUTE_REPNOTIFY(ClassName, AttributeName) \
void ClassName::OnRep_##AttributeName(const FGameplayAttributeData& Old##AttributeName) const \
{ \
GAMEPLAYATTRIBUTE_REPNOTIFY(ClassName, AttributeName, Old##AttributeName); \
}

// Vital - Gameplay Attributes
DEFINE_ATTRIBUTE_REPNOTIFY(UECMAttributeSet, VitalityMatrix)
DEFINE_ATTRIBUTE_REPNOTIFY(UECMAttributeSet, EnergeticEndurance)
DEFINE_ATTRIBUTE_REPNOTIFY(UECMAttributeSet, ArcaneReservoir)
DEFINE_ATTRIBUTE_REPNOTIFY(UECMAttributeSet, DefensiveSynchrony)
DEFINE_ATTRIBUTE_REPNOTIFY(UECMAttributeSet, BarrierMatrix)

// Secondary - Gameplay Attributes
DEFINE_ATTRIBUTE_REPNOTIFY(UECMAttributeSet, VMCapacity)
DEFINE_ATTRIBUTE_REPNOTIFY(UECMAttributeSet, EECapacity)
DEFINE_ATTRIBUTE_REPNOTIFY(UECMAttributeSet, ARCapacity)
DEFINE_ATTRIBUTE_REPNOTIFY(UECMAttributeSet, KineticAbsorption)
DEFINE_ATTRIBUTE_REPNOTIFY(UECMAttributeSet, NanoshieldThreshold)

#undef DEFINE_ATTRIBUTE_REPNOTIFY
#pragma endregion Replicate

#pragma region HelperFunctions

FGameplayAttribute UECMAttributeSet::AttributeFromData(const FGameplayEffectModCallbackData& Data)
{
	// Gets GameplayEffect Prop from Data packet
	FEffectProperties Props;
	SetEffectProperties(Data, Props);

	// Gets Attribute from the Data packet
	const FGameplayAttribute Attribute = Data.EvaluatedData.Attribute;

	return Attribute;
}

void UECMAttributeSet::ClampAttributeInSet(const FGameplayAttribute& Attribute, TArray<AttributeFunctionMappings> AttributeSet)
{
	for (const auto& Mapping : AttributeSet)
	{
		if (Attribute == Mapping.Attribute)
		{
			(this->*Mapping.Setter)(FMath::Clamp((this->*Mapping.Getter)(), 0.f, (this->*Mapping.MaxFunc)()));
			//UE_LOG(LogTemp, Warning, TEXT("Changed Health on %s, Health: %f"), *Props.TargetAvatarActor->GetName(), GetVitalityMatrix());
			return;
		}
	}	
}
#pragma endregion HelperFunctions
